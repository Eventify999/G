import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr'; // 👈 Import this

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [ReactiveFormsModule]
})
export class LoginComponent {
  loginForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private toastr: ToastrService // 👈 Inject this
  ) {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
      rememberMe: [false]
    });
  }

  onLogin() {
    if (this.loginForm.valid) {
      const formValue = this.loginForm.value;

      const loginPayload = {
        Username: formValue.username,
        Password: formValue.password
      };

      this.http.post("https://localhost:5005/api/auth/Login", loginPayload).subscribe({
        next: (res: any) => {
          if (res.result) {
            console.log(res);
            // Store user data and token in localStorage
            localStorage.setItem('loginUser', loginPayload.Username);
            localStorage.setItem('myLogInToken', res.result.token);
            sessionStorage.setItem('isLogged','true');
            const userRoles = res.result.roles;
            console.log('user role : ',userRoles);
            if (userRoles && userRoles.length > 0) {
              const role = userRoles[0]; 
              localStorage.setItem('userRole', role);
              console.log(role);
              if (role === 'Customer') {
                console.log('customer called')
                this.router.navigateByUrl('dashboard/c');
              } else if (role === 'Vendor') {
                console.log('vendor called')
                this.router.navigateByUrl('dashboard/v');
              } else {
                console.log('admin called')
                this.router.navigateByUrl('dashboard');
              }
            }
            this.toastr.success("Login Successful!", "Success"); // ✅ toast

          } else {
            this.toastr.warning(res.message || "Invalid credentials", "Warning"); // ✅ toast
          }
        },
        error: (err) => {
          console.error(err);
          this.toastr.error("Login failed. Please try again.", "Error"); // ✅ toast
        }
      });
    } else {
      this.loginForm.markAllAsTouched();
    }
  }

  navigateToRegister() {
    this.router.navigate(['/register']);
  }

  logOff() {
    localStorage.removeItem('loginUser');
    localStorage.removeItem('myLogInToken');
    localStorage.removeItem('userRole');
    this.router.navigateByUrl('login');
  }
}
