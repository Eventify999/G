import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidatorFn, ValidationErrors } from '@angular/forms';
import { DatePipe, CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { lastValueFrom } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-my-request',
  templateUrl: './my-requests.component.html',
  styleUrls: ['./my-requests.component.css'],
  providers: [DatePipe],
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
})
export class MyRequestComponent implements OnInit {
  private readonly API_BASE_URL = 'https://localhost:5002/api';
  requestForm: FormGroup;
  currentStep = 1;
  totalSteps = 3;
  progressPercentage = 0;
  showForm = false;
  isLoading = false;
  errorMessage = '';

  requestList: any[] = [];

  constructor(
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private http: HttpClient,
    private toastr: ToastrService
  ) {
    this.requestForm = this.fb.group({
      eventRequirementId: [0],
      customerId: [''],
      eventType: ['', Validators.required],
      location: ['', [Validators.required, Validators.minLength(3)]],
      eventDate: ['', [Validators.required, this.futureDateValidator()]],
      numberOfGuests: ['', [Validators.required, Validators.min(1)]],
      specialRequests: [''],
      budget: ['', [Validators.min(0)]],
      description: ['', [Validators.required, Validators.minLength(10)]],
    });
  }

  private futureDateValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) return null;
      const selectedDate = new Date(control.value);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      return selectedDate >= today ? null : { pastDate: true };
    };
  }

  private updateProgress(): void {
    let completedFields = 0;
    const totalFields = 7;

    if (this.requestForm.get('eventType')?.valid) completedFields++;
    if (this.requestForm.get('location')?.valid) completedFields++;
    if (this.requestForm.get('eventDate')?.valid) completedFields++;
    if (this.requestForm.get('numberOfGuests')?.valid) completedFields++;
    if (this.requestForm.get('specialRequests')?.value) completedFields += 0.5;
    if (this.requestForm.get('budget')?.valid) completedFields++;
    if (this.requestForm.get('description')?.valid) completedFields++;

    this.progressPercentage = Math.min(100, Math.round((completedFields / totalFields) * 100));
  }

  async ngOnInit(): Promise<void> {
    this.requestForm.valueChanges.subscribe(() => {
      this.updateProgress();
    });

    await this.loadEventRequirements();
  }

  closeForm(): void {
    this.showForm = false;
    this.requestForm.reset();
    this.currentStep = 1;
  }

  private getApiUrl(path: string): string {
    return `${this.API_BASE_URL}${path}`;
  }

  async loadEventRequirements(): Promise<void> {
    this.isLoading = true;
    this.errorMessage = '';

    try {
      const userId = sessionStorage.getItem('UserId');
      if (!userId) {
        throw new Error('User ID not found in session storage');
      }

      const apiUrl = this.getApiUrl(`/Events/customer/${userId}`);
      const response: any = await lastValueFrom(this.http.get(apiUrl));

      if (response.isSuccess) {
        this.requestList = Array.isArray(response.result) ? response.result : response.result ? [response.result] : [];
      } else {
        this.errorMessage = response.message || 'Failed to load event requirements';
      }
    } catch (error) {
      console.error('Error loading event requirements:', error);
      this.errorMessage = 'Failed to load event requirements. Please try again later.';
    } finally {
      this.isLoading = false;
    }
  }

  isStep1Valid(): boolean {
    return !!this.requestForm.get('eventType')?.valid &&
           !!this.requestForm.get('location')?.valid &&
           !!this.requestForm.get('eventDate')?.valid &&
           !!this.requestForm.get('numberOfGuests')?.valid;
  }

  isStep2Valid(): boolean {
    return !!this.requestForm.get('description')?.valid;
  }

  nextStep(): void {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
      this.updateProgress();
    }
  }

  prevStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
      this.updateProgress();
    }
  }

  async onSubmit(): Promise<void> {
    if (this.requestForm.valid) {
      try {
        this.isLoading = true;
        const userId = sessionStorage.getItem('UserId');
        if (!userId) {
          throw new Error('User ID not found in session storage');
        }

        // Format eventDate to UTC with 'Z' suffix
        const eventDate = new Date(this.requestForm.value.eventDate);
        const formattedEventDate = eventDate.toISOString();

        // Prepare event data
        const eventData = {
          ...this.requestForm.value,
          customerId: userId,
          eventDate: formattedEventDate,
        };
        console.log('Request being sent:', eventData);

        // Determine if it's a create (POST) or update (PUT) request
        const isUpdate = eventData.eventRequirementId !== 0;
        const eventApiUrl = this.getApiUrl('/Events');
        const eventResponse: any = await lastValueFrom(
          isUpdate
            ? this.http.put(eventApiUrl, eventData)
            : this.http.post(eventApiUrl, eventData)
        );

        if (!eventResponse.isSuccess) {
          throw new Error(eventResponse.message || `Failed to ${isUpdate ? 'update' : 'create'} event`);
        }

        console.log('Event response received:', eventResponse);

        // If creating a new event, also create a service request
        if (!isUpdate) {
          // Create Service Request
          const serviceRequestData = {
            requestId: 0,
            customerId: userId,
            eventRequirementId: eventResponse.result.eventRequirementId,
            requestedAt: new Date().toISOString(),
            status: 'Pending',
          };

          const serviceRequestApiUrl = this.getApiUrl('/ServiceRequest');
          const serviceRequestResponse: any = await lastValueFrom(
            this.http.post(serviceRequestApiUrl, serviceRequestData)
          );

          if (!serviceRequestResponse.isSuccess) {
            throw new Error(serviceRequestResponse.message || 'Failed to create service request');
          }

          console.log('Service request response received:', serviceRequestResponse);
        }

        // Show success toast
        this.toastr.success(
          isUpdate ? 'Event updated successfully!' : 'Request submitted successfully!',
          'Success'
        );

        // Refresh the list and reset form
        await this.loadEventRequirements();
        this.closeForm();
      } catch (error) {
        console.error('Error submitting form:', error);
        this.toastr.error(
          error instanceof Error ? error.message : 'Unknown error',
          'Error'
        );
      } finally {
        this.isLoading = false;
      }
    } else {
      this.requestForm.markAllAsTouched();
      this.toastr.error('Please fill out all required fields correctly.', 'Form Error');
    }
  }

  editRequest(request: any): void {
    // Format the eventDate for the form input
    const formattedRequest = {
      ...request,
      eventDate: this.formatDateForInput(request.eventDate),
    };

    // Populate the form with the request data
    this.requestForm.patchValue(formattedRequest);

    // Open the modal
    this.showForm = true;
    this.currentStep = 1;
    this.updateProgress();
  }

  async deleteRequest(id: number): Promise<void> {
    const confirmed = confirm('Are you sure you want to delete this request?');
    if (confirmed) {
      try {
        this.isLoading = true;
        const apiUrl = this.getApiUrl(`/Events/${id}`);
        await lastValueFrom(this.http.delete(apiUrl));
        await this.loadEventRequirements();
        this.toastr.success('Request deleted successfully!', 'Success');
      } catch (error) {
        console.error('Error deleting request:', error);
        this.toastr.error('Failed to delete request. Please try again.', 'Error');
      } finally {
        this.isLoading = false;
      }
    }
  }

  private formatDateForInput(apiDate: string): string {
    const date = new Date(apiDate);
    return date.toISOString().split('T')[0];
  }
}