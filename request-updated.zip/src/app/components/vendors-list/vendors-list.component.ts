import { Component } from '@angular/core';

@Component({
  selector: 'app-vendors-list',
  imports: [],
  templateUrl: './vendors-list.component.html',
  styleUrl: './vendors-list.component.scss'
})
export class VendorsListComponent {

}
