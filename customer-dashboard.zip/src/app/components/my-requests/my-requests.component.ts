import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { DatePipe, CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-my-request',
  templateUrl: './my-requests.component.html',
  styleUrls: ['./my-requests.component.css'],
  providers: [DatePipe],
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule]
})
export class MyRequestComponent implements OnInit {
  requestForm: FormGroup;
  currentStep = 1;
  totalSteps = 3;
  progressPercentage = 0;
  showForm = false;

  requestList: any[] = [
    {
      id: 1,
      eventType: 'Wedding',
      location: 'Trivandrum, Kerala',
      eventDate: new Date(),
      numberOfGuests: 150,
      budget: 10000,
      description: 'Traditional wedding ceremony with custom decor.'
    },
    {
      id: 2,
      eventType: 'Birthday',
      location: 'Kochi, Kerala',
      eventDate: new Date(),
      numberOfGuests: 50,
      budget: 3000,
      description: 'Outdoor birthday party for kids with games and cake.'
    }
  ];

  constructor(private fb: FormBuilder, private datePipe: DatePipe) {
    this.requestForm = this.fb.group({
      eventRequirementId: [0],
      customerId: [0],
      eventType: ['', Validators.required],
      location: ['', [Validators.required, Validators.minLength(3)]],
      eventDate: ['', [Validators.required, this.futureDateValidator()]],
      numberOfGuests: ['', [Validators.required, Validators.min(1)]],
      specialRequests: [''],
      budget: ['', [Validators.min(0)]],
      description: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  ngOnInit(): void {
    this.requestForm.valueChanges.subscribe(() => {
      this.updateProgress();
    });
  }

  closeForm() {
    this.showForm = false;
    // Reset form if needed
    // this.requestForm.reset();
    // this.currentStep = 1;
  }

  futureDateValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      if (!control.value) return null;
      const selectedDate = new Date(control.value);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      return selectedDate >= today ? null : { pastDate: true };
    };
  }

  updateProgress(): void {
    let completedFields = 0;
    const totalFields = 7;

    if (this.requestForm.get('eventType')?.valid) completedFields++;
    if (this.requestForm.get('location')?.valid) completedFields++;
    if (this.requestForm.get('eventDate')?.valid) completedFields++;
    if (this.requestForm.get('numberOfGuests')?.valid) completedFields++;
    if (this.requestForm.get('specialRequests')?.value) completedFields += 0.5;
    if (this.requestForm.get('budget')?.valid) completedFields++;
    if (this.requestForm.get('description')?.valid) completedFields++;

    this.progressPercentage = Math.min(100, Math.round((completedFields / totalFields) * 100));
  }

  isStep1Valid(): boolean {
    return !!this.requestForm.get('eventType')?.valid &&
           !!this.requestForm.get('location')?.valid &&
           !!this.requestForm.get('eventDate')?.valid &&
           !!this.requestForm.get('numberOfGuests')?.valid;
  }
  

  isStep2Valid(): boolean {
    return !!this.requestForm.get('description')?.valid;
  }

  nextStep(): void {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
      this.updateProgress();
    }
  }

  prevStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
      this.updateProgress();
    }
  }

  onSubmit(): void {
    if (this.requestForm.valid) {
      const formValue = {
        ...this.requestForm.value,
        eventDate: this.datePipe.transform(this.requestForm.value.eventDate, 'yyyy-MM-ddTHH:mm:ss.SSSZ')
      };

      console.log('Form submitted:', formValue);
      alert('Request submitted successfully!');

      this.requestList.push({
        id: Date.now(),
        ...formValue
      });

      this.requestForm.reset();
      this.currentStep = 1;
      this.progressPercentage = 0;
      this.showForm = false;
    } else {
      this.requestForm.markAllAsTouched();
    }
  }

  editRequest(request: any): void {
    this.requestForm.patchValue(request);
    this.showForm = true;
    this.currentStep = 1;
    this.updateProgress();
  }

  deleteRequest(id: number): void {
    const confirmed = confirm('Are you sure you want to delete this request?');
    if (confirmed) {
      this.requestList = this.requestList.filter(r => r.id !== id);
    }
  }
}
